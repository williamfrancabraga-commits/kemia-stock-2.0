# Aumento da Produtividade no Setor de Estoque — Kemia Stock

Protótipo demonstrativo do Projeto Integrador.

## Endereço do GitHub Pages
https://willian.github.io/aumento-produtividade-estoque/

## Publicar
1. Crie no GitHub um repositório público chamado `aumento-produtividade-estoque`.
2. Envie o arquivo `index.html` para a raiz do repositório.
3. Abra **Settings > Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Selecione `main` e `/ (root)`, depois clique em **Save**.

Após a publicação, o site ficará disponível no endereço acima. A publicação ainda precisa ser feita na sua conta do GitHub.

## Observação
Este é um protótipo demonstrativo. As movimentações são temporárias na sessão e não há banco de dados ou integração com ERP.
